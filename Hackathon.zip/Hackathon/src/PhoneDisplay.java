import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class PhoneDisplay extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		String os = request.getParameter("os");
		int dsize = Integer.parseInt(request.getParameter("dsize"));
		int camera = Integer.parseInt(request.getParameter("camera"));
		int battery = Integer.parseInt(request.getParameter("battery"));
		System.out.println(dsize+" "+camera+" "+battery);
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager
					.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
							"project", "project");
			PreparedStatement ps = con
					.prepareStatement("select * from phones where os=? and disize=? and camera=? and battery=?");
			ps.setString(1, os);
			ps.setInt(2, dsize);
			ps.setInt(3, camera);
			ps.setInt(4, battery);
			ResultSet rs = ps.executeQuery();
			//StringBuffer tab = new StringBuffer();
			StringBuilder tab = new StringBuilder();
				
				while (rs.next()) {
					tab.append("<tr><td><input type='radio' name='optphone' value="
							+ rs.getInt(1) + ">" + "</td>"+
					"<td>" + rs.getString(2) + "</td><td>"
							+ rs.getString(3) + "</td><td>" + rs.getString(4)
							+ "</td><td>" + rs.getString(5) + "</td><td>"
							+ rs.getString(6) + "</td><td>" + rs.getString(7)
							+ "</td></tr>");
				}
				tab.append("</tbody></table>");
				tab.append("<div class = 'col-md-12 col-md-offset-10'><span class='form-group'><input type='number' class='form-control' name='qtyReq' id='qtyReq'></span><input type='Submit' class='btn btn-success btn-sm' id='buy' value='Buy'></form></div>");
						
				System.out.println(tab.toString());
				out.println(tab.toString());	

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
