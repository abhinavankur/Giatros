import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class PhoneDisplay extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		String os = request.getParameter("os");
		int dsize = Integer.parseInt(request.getParameter("dsize"));
		int camera = Integer.parseInt(request.getParameter("camera"));
		int battery = Integer.parseInt(request.getParameter("battery"));
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager
					.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
							"project", "project");
			PreparedStatement ps = con
					.prepareStatement("select * from phones where os=? and disize=? and camera=? and battery=?");
			ps.setString(1, os);
			ps.setInt(2, dsize);
			ps.setInt(3, camera);
			ps.setInt(4, battery);
			ResultSet rs = ps.executeQuery();
			StringBuffer tab = new StringBuffer();
			tab.append("<table class='table table-bordered'><thead><tr><th>Select</th><th>Product Name</th><th>Company</th><th>OS</th><th>Screen Size</th><th>Camera</th><th>Battery</th></tr></thead><tbody>");

			while (rs.next()) {
				/*tab.append("<td><input type='radio' name='optphone' value='"
						+ rs.getString(2) + "'>" + rs.getString(2) + "</td>");*/
				tab.append("<tr><td>" + rs.getString(2) + "</td><td>" + rs.getString(2) + "</td><td>"
						+ rs.getString(3) + "</td><td>" + rs.getString(4)
						+ "</td><td>" + rs.getString(5) + "</td><td>"
						+ rs.getString(6) + "</td><td>" + rs.getString(7)
						+ "</td></tr>");
			}
			tab.append("</tbody></table>");

			out.println(tab.toString());

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
