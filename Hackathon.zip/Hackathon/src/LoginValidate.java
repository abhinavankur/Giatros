

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html"); 
        String email = request.getParameter("inputEmail");
        String pass = request.getParameter("inputPassword");
        try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","project","project");
            PreparedStatement ps =con.prepareStatement("select * from employee where eemail=?");
            ps.setString(1, email);
            ResultSet rs =ps.executeQuery();
            String pass1=null;
            while(rs.next()){
            	pass1=rs.getString("password");
            }
            out.println(email+" "+pass+" "+pass1);
            if(pass.equals(pass1))
            {
            	HttpSession session=request.getSession();
            	session.setAttribute(email,"email");
                RequestDispatcher rs1 = request.getRequestDispatcher("showPhones.html");
                rs1.forward(request, response);
            }
            else
            {
               out.println("Username or Password incorrect");
               RequestDispatcher rs2 = request.getRequestDispatcher("login.html");
               rs2.include(request, response);
            }
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
