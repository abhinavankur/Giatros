
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class FinalOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String mob =  (String) session.getAttribute("cphone");
		String cname = request.getParameter("cname");
		String cmail = request.getParameter("cemail");
		System.out.println(mob);
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager
					.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
							"project", "project");
			PreparedStatement ps = con.prepareStatement("insert into customer values(customer_cid.nextval,?,?,?)");
			ps.setString(1, cname);
			ps.setString(2, mob);
			ps.setString(3, cmail);
			ps.executeQuery();
			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);
			System.out.println("session final order : "+session.getAttribute("order").toString().equals("self"));
			if (session.getAttribute("order").toString().equals("self")) {
				PreparedStatement pst = con.prepareStatement("update reposit set quantity=? where rid=? and pid=?");
				pst.setInt(1,Integer.parseInt((String) session.getAttribute("quantity"))- Integer.parseInt((String) session
										.getAttribute("qtyReq")));
				pst.setInt(2,
						Integer.parseInt((String) session.getAttribute("rid")));
				pst.setInt(3,
						Integer.parseInt((String) session.getAttribute("pid")));
				pst.executeQuery();
				PreparedStatement pst1 = con
						.prepareStatement("insert into orders values(orders_oid.nextval,?,?,?,?,?)");
				pst1.setInt(1,
						Integer.parseInt((String) session.getAttribute("rid")));
				pst1.setString(2, mob);
				pst1.setInt(3,
						Integer.parseInt((String) session.getAttribute("pid")));
				pst1.setInt(4, Integer.parseInt((String) session
						.getAttribute("qtyReq")));
				pst1.setDate(5, date);
				pst1.executeQuery();
			}
			/*
			 * else if(session.getAttribute("order").equals("fullotherstore")){
			 * int nearRep=56; PreparedStatement pst1 =con.prepareStatement(
			 * "update repository set quantity=? where rid=? and pid=?");
			 * pst.setInt(1, Integer.parseInt((String)
			 * session.getAttribute("quantity"))-Integer.parseInt((String)
			 * session.getAttribute("qtyReq"))); pst.setInt(2,nearRep);
			 * pst.setInt(3,Integer.parseInt((String)
			 * session.getAttribute("pid"))); pst.executeQuery();
			 * PreparedStatement pst1 =con.prepareStatement(
			 * "insert into orders values(orders_oid.nextval,?,?,?,?,?)");
			 * pst1.setInt(1,nearRep); pst1.setInt(2,mob);
			 * pst1.setInt(3,Integer.parseInt((String)
			 * session.getAttribute("pid")));
			 * pst1.setInt(4,Integer.parseInt((String)
			 * session.getAttribute("qtyReq")) ); pst1.setDate(5,date );
			 * pst1.executeQuery(); }
			 */
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		;
	}

	/*
	 * protected boolean checkQty(int repid){ HttpSession
	 * session=request.getSession(); Class.forName("oracle.jdbc.OracleDriver");
	 * Connection
	 * con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe"
	 * ,"project","project"); PreparedStatement pst2
	 * =con.prepareStatement("select * from repository where rid=? and pid=?");
	 * pst2.setInt(1,repid); pst2.setInt(2,Integer.parseInt((String)
	 * session.getAttribute("pid"))); ResultSet rs=pst2.executeQuery(); int
	 * qty=rs.getInt(4); if(qty>=Integer.parseInt((String)
	 * session.getAttribute("qtyReq"))) return true; else return false; }
	 */

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
