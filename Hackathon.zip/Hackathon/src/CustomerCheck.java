

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CustomerCheck
 */
public class CustomerCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session=request.getSession();
        int mob = Integer.parseInt(request.getParameter("cphone"));
        session.setAttribute(Integer.toString(mob),"cphone");
        try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","project","project");
            PreparedStatement ps =con.prepareStatement("select * from customer where mob=?");
            ps.setInt(1, mob);
            ResultSet rs =ps.executeQuery();
            StringBuffer tab=new StringBuffer();
            tab.append("flag=");
            if(rs.next()){
            	tab.append("1");
            	tab.append(rs.getString(2)+"&"+rs.getString(4));
            }
            else{
                tab.append("0");
            }
            out.println(tab.toString());
           
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
