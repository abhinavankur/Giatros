import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;


public class Caller{	
		public static void main(String[] args) throws Exception {

		    //the Date and time at which you want to execute
		    DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    Date date = dateFormatter .parse("2016-08-18 00:00:00");

		    //Now create the time and schedule it
		    Timer timer = new Timer();

		    //Use this if you want to execute it repeatedly
		    int period = 1000*60*60*24;
		    timer.schedule(new MyTimer(), date, period );
		}

	}


