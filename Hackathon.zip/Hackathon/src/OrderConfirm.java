

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class OrderConfirm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		HttpSession session=request.getSession();
		int qtyReq= Integer.parseInt(request.getParameter("quantity"));
		int pid = Integer.parseInt(request.getParameter("pid"));
		session.setAttribute(Integer.toString(qtyReq), "qtyReq");
		String email=(String) session.getAttribute("email"); 
	            try {
	            	response.setContentType("text/html");
	            	Class.forName("oracle.jdbc.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","project","project");
					PreparedStatement ps =con.prepareStatement("select rid from employee where eemail=? ");
					ps.setString(1,email);
					ResultSet rs;
					rs=ps.executeQuery();
					int rid=rs.getInt(1);
					PreparedStatement ps1 =con.prepareStatement("select * from repository where rid=? and pid=?");
					ps1.setInt(1,rid);
					ps1.setInt(2, pid);
					rs=ps1.executeQuery();
					int qty=rs.getInt(4);
					session.setAttribute(Integer.toString(rid), "rid");
					session.setAttribute(Integer.toString(pid), "pid");
					session.setAttribute(Integer.toString(qty), "quantity");
					RequestDispatcher rd = request.getRequestDispatcher("CustomerDetails.html");
	                rd.forward(request, response);
					if(qty>qtyReq){
						session.setAttribute("self", "order");
					}
					else if(qty==0)
					{
						session.setAttribute("fullotherstore", "order");
					}
					else{
						session.setAttribute("partialotherstore", "order");
					}
					
				}  catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
