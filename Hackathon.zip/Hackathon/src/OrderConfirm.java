import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class OrderConfirm extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ResultSet rs1 = null;
	int rid = 0, qty = 0;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		HttpSession session = request.getSession();
		int qtyReq = Integer.parseInt(request.getParameter("qtyReq"));
		int pid = Integer.parseInt(request.getParameter("optphone"));
		session.setAttribute("qtyReq", Integer.toString(qtyReq));
		String email = (String) session.getAttribute("email");
		System.out.println("EMAIL : " + email);
		try {
			response.setContentType("text/html");
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con = DriverManager
					.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
							"project", "project");
			PreparedStatement ps = con
					.prepareStatement("select rid from employee where eemail=? ");
			ps.setString(1, email);
			ResultSet rs;
			rs = ps.executeQuery();
			while (rs.next()) {
				rid = rs.getInt(1);
			}
			PreparedStatement ps1 = con
					.prepareStatement("select quantity from reposit where rid=? and pid=?");

			ps1.setInt(1, rid);
			ps1.setInt(2, pid);
			System.out.println("RID : " + rid + " PID = " + pid);
			rs1 = ps1.executeQuery();
			while (rs1.next()) {
				qty = rs1.getInt(1);
				System.out.println(rs1.getInt(1));
			}
			session.setAttribute("rid", Integer.toString(rid));
			session.setAttribute("pid", Integer.toString(pid));
			session.setAttribute("quantity", Integer.toString(qty));

			System.out.println("QTY: " + qty + "QTYREQ: " + qtyReq);
			if (qty > qtyReq) {

				System.out.println("self");
				session.setAttribute("order", "self");
			} else if (qty == 0) {
				System.out.println("fullotherstore");
				session.setAttribute("order", "fullotherstore");
			} else {
				System.out.println("partialotherstore");
				session.setAttribute("order", "partialotherstore");
			}
			RequestDispatcher rd = request
					.getRequestDispatcher("CustomerDetails.html");
			rd.forward(request, response);

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
