
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.TimerTask;

public class MyTimer extends TimerTask
{

	public void run()
	{
		int data[]={40,13,36,45,48,50,39};
		int qty,i;
		ResultSet rs0;
		ResultSet rs = null ;

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","project","project");
			PreparedStatement ps =con.prepareStatement("select count(*) from orders");
			ps.executeQuery();
			int count=Integer.parseInt(rs.getString(1));
			for(i=0;i<count;i++){
				String s = "select substr(dat(3,5)) from orders";
				PreparedStatement ps1 =con.prepareStatement("select quantity=quantity+data[substr(dat(3,5))-1]," +
						"substr(dat,3,5)as Month from orders order by Month ");
				ps1.setInt(1, 1);

				rs=ps.executeQuery();
			}
			while(rs.next()){
				int q=Integer.parseInt(rs.getString(1));
				int d=Integer.parseInt(rs.getString(2));
				PreparedStatement ps1=con.prepareStatement("insert into month_data values(?,?)");
				ps.setInt(1, q);
				ps.setInt(2,d);
				ps.executeUpdate();
				con.commit();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{}
	}
}
